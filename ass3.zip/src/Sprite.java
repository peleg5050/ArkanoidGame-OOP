// ID: 208387969

import biuoop.DrawSurface;

/**
 * Sprite - The interface sprites can be drawn on the screen, and can be notified that time has passed
 * (so that they know to change their position / shape / appearance / etc).
 * In our design, all of the game objects as: Ball, Block, Paddle, ... are Sprites so they will implement
 * the Sprite interface
 */
public interface Sprite {
    /**
     * drawOn - Draw the sprite to the screen.
     *
     * @param draw - The draw.
     */
    void drawOn(DrawSurface draw);

    /**
     * timePassed - notify that time has passed.
     */
    void timePassed();
}
